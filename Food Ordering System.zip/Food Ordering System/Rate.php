<?php
     $RadioButton = $_POST['RadioButton']
     $Review = $_POST['Review']

     $conn = new mysqli('localhost','username','password','database_name');
     $conn = $RadioButton&& $Review
?>