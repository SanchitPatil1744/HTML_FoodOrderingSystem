<?php
    $Name = $_POST['Name']
    $Username = $_POST['Username']
    $Phone= $_POST['Phone']
    $Password = $_POST['Password']
    $Address = $_POST['Address']

    $conn = new mysqli('localhost','username','password','database_name');
     if($conn->connect_error)
     {
        die('Connection Failed :' .$conn->connect_error);
     }
     else
     {
        $stmt = $conn->prepare("Insert into registration(Name, Username, Phone, Password, Address) values(?,?,?,?,?)");
        $stmt->bind_param("ssiss", $Name, $Username, $Phone, $Password, $Address);
        $stmt->execute();
        echo "Registration Successful...";
        $stmt->close();
        $conn->close();
     }
?>
